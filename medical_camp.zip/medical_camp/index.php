<?php include('partials/header.php'); ?>

<div class="container mt-5">
    <div class="jumbotron">
        <h1 class="display-4">Universal Medical Camp - Global Outreach</h1>
        <p class="lead">Monitor patient progress, caregivers, request services, and manage clinical reports.</p>
        <hr class="my-4">
        <a class="btn btn-primary btn-lg" href="pages/dashboard.php" role="button">Go to Dashboard</a>
    </div>
</div>

<?php include('partials/footer.php'); ?>
