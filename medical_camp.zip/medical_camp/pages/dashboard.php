<?php include('../partials/header.php'); ?>
<?php include('../config/db.php'); ?>

<div class="container mt-5">
    <h2>Medical Camp Dashboard</h2>
    <div class="row mb-4">
        <div class="col-md-3">
            <a href="add_patient.php" class="btn btn-primary">Add Patient</a>
        </div>
        <div class="col-md-3">
            <a href="add_caregiver.php" class="btn btn-primary">Add Caregiver</a>
        </div>
        <div class="col-md-3">
            <a href="request_service.php" class="btn btn-primary">Request Medical Service</a>
        </div>
        <div class="col-md-3">
            <a href="add_report.php" class="btn btn-primary">Add Clinical Report</a>
        </div>
    </div>

    <h4>Current Patients</h4>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Diagnosis</th>
                <th>Progress</th>
                <th>Last Update</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM patients";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['name']}</td>
                            <td>{$row['age']}</td>
                            <td>{$row['diagnosis']}</td>
                            <td>{$row['progress']}</td>
                            <td>{$row['last_update']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No patients available</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>
</div>

<?php include('../partials/footer.php'); ?>
