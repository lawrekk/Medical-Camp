<?php include('../partials/header.php'); ?>
<?php include('../config/db.php'); ?>

<div class="container mt-5">
    <h2>Add New Patient</h2>
    <form action="add_patient.php" method="POST">
        <div class="form-group">
            <label for="name">Patient Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="age">Age</label>
            <input type="number" class="form-control" id="age" name="age" required>
        </div>
        <div class="form-group">
            <label for="diagnosis">Diagnosis</label>
            <textarea class="form-control" id="diagnosis" name="diagnosis" rows="3" required></textarea>
        </div>
        <div class="form-group">
            <label for="progress">Progress</label>
            <textarea class="form-control" id="progress" name="progress" rows="3" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Add Patient</button>
    </form>
</div>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $diagnosis = $_POST['diagnosis'];
    $progress = $_POST['progress'];

    $sql = "INSERT INTO patients (name, age, diagnosis, progress) VALUES ('$name', '$age', '$diagnosis', '$progress')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New patient added successfully');</script>";
        echo "<script>window.location.href = 'dashboard.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<?php include('../partials/footer.php'); ?>
