<?php include('../partials/header.php'); ?>
<?php include('../config/db.php'); ?>

<div class="container mt-5">
    <h2>Add New Caregiver</h2>
    <form action="add_caregiver.php" method="POST">
        <div class="form-group">
            <label for="name">Caregiver Name</label>
            <input type="text" class="form-control" id="name"
